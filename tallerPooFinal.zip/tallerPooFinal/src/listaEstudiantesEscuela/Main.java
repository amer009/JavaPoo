package listaEstudiantesEscuela;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Escuela escuela = new Escuela();

        // Agregar al menos tres estudiantes
        escuela.agregarEstudiante(new Estudiante("Ana", 1, 9.5));
        escuela.agregarEstudiante(new Estudiante("Carlos", 2, 8.0));
        escuela.agregarEstudiante(new Estudiante("Lucía", 3, 7.5));

        boolean salir = false;
        while (!salir) {
            System.out.println("Menú de opciones:");
            System.out.println("1. Agregar nuevo estudiante");
            System.out.println("2. Buscar estudiante por número de identificación");
            System.out.println("3. Actualizar estudiante");
            System.out.println("4. Salir");
            System.out.print("Elige una opción: ");
            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.print("Nombre del estudiante: ");
                    String nombre = scanner.next();
                    System.out.print("Número de identificación: ");
                    int id = scanner.nextInt();
                    System.out.print("Calificación: ");
                    double calificacion = scanner.nextDouble();

                    // Validación de calificación
                    if (calificacion < 0 || calificacion > 10) {
                        System.out.println("La calificación debe estar entre 0 y 10.");
                    } else {
                        Estudiante nuevoEstudiante = new Estudiante(nombre, id, calificacion);
                        if (escuela.agregarEstudiante(nuevoEstudiante)) {
                            System.out.println("Estudiante agregado correctamente.");
                        } else {
                            System.out.println("Ya existe un estudiante con ese número de identificación.");
                        }
                    }
                    break;

                case 2:
                    System.out.print("Introduce el número de identificación del estudiante: ");
                    int idBusqueda = scanner.nextInt();
                    escuela.buscarEstudiante(idBusqueda)
                            .ifPresentOrElse(
                                    estudiante -> System.out.println("Estudiante encontrado: " + estudiante),
                                    () -> System.out.println("Estudiante no encontrado.")
                            );
                    break;

                case 3:
                    System.out.println("Introduce el número de identificación del estudiante a actualizar: ");
                    int idActualizar = scanner.nextInt();

                    // Buscar si el estudiante existe
                    if (escuela.buscarEstudiante(idActualizar).isPresent()) {
                        System.out.print("Nuevo nombre: ");
                        String nuevoNombre = scanner.next();
                        System.out.print("Nueva Identificación: ");
                        int nuevoId = scanner.nextInt();
                        System.out.print("Nueva calificación: ");
                        double nuevaCalificacion = scanner.nextDouble();

                        // Validación de calificación
                        if (nuevaCalificacion < 0 || nuevaCalificacion > 10) {
                            System.out.println("La calificación debe estar entre 0 y 10.");
                        } else {
                            // Validar si el nuevo número de identificación ya está en uso
                            if (nuevoId != idActualizar && escuela.buscarEstudiante(nuevoId).isPresent()) {
                                System.out.println("Error: El nuevo número de identificación ya está en uso por otro estudiante.");
                            } else {
                                // Actualizar estudiante
                                if (escuela.actualizarEstudiante(idActualizar, nuevoNombre, nuevoId, nuevaCalificacion)) {
                                    System.out.println("Estudiante actualizado correctamente.");
                                } else {
                                    System.out.println("Error al actualizar estudiante.");
                                }
                            }
                        }
                    } else {
                        System.out.println("Estudiante no encontrado.");
                    }
                    break;

                case 4:
                    salir = true;
                    break;

                default:
                    System.out.println("Opción no válida.");
            }
        }

        scanner.close();
    }
}
