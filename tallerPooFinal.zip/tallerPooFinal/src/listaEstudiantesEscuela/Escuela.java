package listaEstudiantesEscuela;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

public class Escuela {
    private Set<Estudiante> listaEstudiantes;

    public Escuela() {
        this.listaEstudiantes = new HashSet<>();
    }

    // Método para agregar estudiante
    public boolean agregarEstudiante(Estudiante estudiante) {
        // Validar que el número de identificación no esté repetido
        Optional<Estudiante> estudianteExistente = buscarEstudiante(estudiante.getNumeroIdentificacion());
        if (estudianteExistente.isPresent()) {
            return false; // El estudiante ya existe
        }
        return listaEstudiantes.add(estudiante); // Agregar estudiante si no está repetido
    }

    // Método para buscar estudiante por número de identificación
    public Optional<Estudiante> buscarEstudiante(int numeroIdentificacion) {
        return listaEstudiantes.stream()
                .filter(estudiante -> estudiante.getNumeroIdentificacion() == numeroIdentificacion)
                .findFirst();
    }

    // Método para actualizar estudiante
    public boolean actualizarEstudiante(int numeroIdentificacion, String nuevoNombre, int nuevoId, double nuevaCalificacion) {
        Optional<Estudiante> estudiante = buscarEstudiante(numeroIdentificacion);
        if (estudiante.isPresent()) {
            estudiante.get().setNombre(nuevoNombre);
            estudiante.get().setNumeroIdentificacion(nuevoId);
            estudiante.get().setCalificacion(nuevaCalificacion);
            return true;
        }
        return false;
    }

    // Método para eliminar estudiante
    public boolean eliminarEstudiante(int numeroIdentificacion) {
        Optional<Estudiante> estudiante = buscarEstudiante(numeroIdentificacion);
        if (estudiante.isPresent()) {
            return listaEstudiantes.remove(estudiante.get());
        }
        return false;
    }
}
