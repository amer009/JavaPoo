package Figuras;

public interface Movible {
    void moverHorizontalmente(int distancia);
    void moverVerticalmente(int distancia);
}

