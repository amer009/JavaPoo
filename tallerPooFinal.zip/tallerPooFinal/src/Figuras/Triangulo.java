package Figuras;

public class Triangulo extends Figura implements Movible, Dibujable {
    private double base, altura;

    public Triangulo(String color, int x, int y, double base, double altura) {
        super(color, x, y);
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return (base * altura) / 2;
    }

    @Override
    public double calcularPerimetro() {
        // Suponemos un triángulo equilátero para simplificar
        return 3 * base;
    }

    @Override
    public void moverHorizontalmente(int distancia) {
        x += distancia;
    }

    @Override
    public void moverVerticalmente(int distancia) {
        y += distancia;
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un triángulo de base " + base + " y altura " + altura + " en (" + x + ", " + y + ")");
    }

    @Override
    public void rotar() {
        System.out.println("Rotando el triángulo.");
    }
}

