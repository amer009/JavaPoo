package Figuras;

public interface Dibujable {
    void dibujar();
    void rotar();
}
