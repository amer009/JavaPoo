package Figuras;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int option;
        do {
            System.out.println("Menú:");
            System.out.println("1. Crear Círculo");
            System.out.println("2. Crear Rectángulo");
            System.out.println("3. Crear Triángulo");
            System.out.println("4. Salir");
            System.out.print("Selecciona una opción: ");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Ingrese el color del círculo: ");
                    String colorCirculo = scanner.next();
                    System.out.print("Ingrese la posición X: ");
                    int xCirculo = scanner.nextInt();
                    System.out.print("Ingrese la posición Y: ");
                    int yCirculo = scanner.nextInt();
                    System.out.print("Ingrese el radio: ");
                    double radio = scanner.nextDouble();
                    Circulo circulo = new Circulo(colorCirculo, xCirculo, yCirculo, radio);
                    System.out.println("Área: " + circulo.calcularArea());
                    System.out.println("Perímetro: " + circulo.calcularPerimetro());
                    circulo.dibujar();
                    break;
                case 2:
                    System.out.print("Ingrese el color del rectángulo: ");
                    String colorRectangulo = scanner.next();
                    System.out.print("Ingrese la posición X: ");
                    int xRectangulo = scanner.nextInt();
                    System.out.print("Ingrese la posición Y: ");
                    int yRectangulo = scanner.nextInt();
                    System.out.print("Ingrese la base: ");
                    double base = scanner.nextDouble();
                    System.out.print("Ingrese la altura: ");
                    double altura = scanner.nextDouble();
                    Rectangulo rectangulo = new Rectangulo(colorRectangulo, xRectangulo, yRectangulo, base, altura);
                    System.out.println("Área: " + rectangulo.calcularArea());
                    System.out.println("Perímetro: " + rectangulo.calcularPerimetro());
                    rectangulo.dibujar();
                    break;
                case 3:
                    System.out.print("Ingrese el color del triángulo: ");
                    String colorTriangulo = scanner.next();
                    System.out.print("Ingrese la posición X: ");
                    int xTriangulo = scanner.nextInt();
                    System.out.print("Ingrese la posición Y: ");
                    int yTriangulo = scanner.nextInt();
                    System.out.print("Ingrese la base: ");
                    double baseTriangulo = scanner.nextDouble();
                    System.out.print("Ingrese la altura: ");
                    double alturaTriangulo = scanner.nextDouble();
                    Triangulo triangulo = new Triangulo(colorTriangulo, xTriangulo, yTriangulo, baseTriangulo, alturaTriangulo);
                    System.out.println("Área: " + triangulo.calcularArea());
                    System.out.println("Perímetro: " + triangulo.calcularPerimetro());
                    triangulo.dibujar();
                    break;
                case 4:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida. Intenta de nuevo.");
            }
        } while (option != 4);
        scanner.close();
    }
}

